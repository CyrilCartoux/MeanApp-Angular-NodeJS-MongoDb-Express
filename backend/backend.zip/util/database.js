const mongoose = require("mongoose")

const db = () => {
    return mongoose.connect("mongodb+srv://6ssou:" + process.env.MONGO_ATLAS_PASS + "@cluster0-kkpzf.gcp.mongodb.net/posts?retryWrites=true&w=majority")
}

module.exports = db